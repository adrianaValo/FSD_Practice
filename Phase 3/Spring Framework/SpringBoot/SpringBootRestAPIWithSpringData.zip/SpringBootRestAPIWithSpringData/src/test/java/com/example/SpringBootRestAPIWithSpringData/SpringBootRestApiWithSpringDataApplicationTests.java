package com.example.SpringBootRestAPIWithSpringData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestApiWithSpringDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
