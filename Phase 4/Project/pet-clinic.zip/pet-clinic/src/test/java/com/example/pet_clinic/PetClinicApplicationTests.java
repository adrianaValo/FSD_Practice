package com.example.pet_clinic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetClinicApplicationTests {

	@Test
	void contextLoads() {
	}

}
